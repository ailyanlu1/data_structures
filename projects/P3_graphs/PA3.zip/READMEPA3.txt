READMEPA3.txt 
BLAKE CONRAD


This program is specifically built for the assignment that was given to me via PDF labeled as PA3 and for nothing else. It was not clearly shown to me before the night before (when I am double checking all of my work) that there were extra files to test my program on. Thus, I literally spent 50+ hours into this assignment to work very good on the example illustrated in the PDF. I have tried my best to submit the best of my work with the remains of what I tried to get done for the new user input (which I did not successfully complete). The code I do have I will now describe in as concise of a manner as possible:

1. LinkedList - implemented as smaller class inside of my Graph.h. Built to simply hold a node, and a pointer to the next node. It’s only functionality is to addNodes; printList is just for debugging

2. Vertex, Edge - also smaller classes inside of Graph.h

3. Graph::readGraph(string): 
	a. scan the entire file by manipulating strings
	b. for all lines, store the 1st and 2nd number in each line into a small array called, “arr” and place that array into an array of array’s called “house”. House is my living representation of all of the data from the given data file.
	c. turn my data from the “house” into vertices with edges and weights through a series of for loops and building of dynamic counters to count up how many edges exist to structure precise for loops
	d. vertexArray[] is an array of vertices, kind of like an Adjacency List
	e. mainList[]’s indices correspond to vertices, while each index holds a link list of the appropriate vertex’s adjacent neighbors.
	f. map[][] and AdjList[][] are supplimental to vertexArray[] and mainList[] to scan through my graph
	g. listArr is simply used to set up my mainList


4. Graph::DFS():
	a. I use a queue to push on the root, then scan all other adjacent vertices of the current root, so long as my linked list is not null, i will look through my adjacent vertices and find the vertex with attached with the least weight(thats my for loop in my initial if statement) and then drop it into the queue, then DFS recursively. My main condition is to check and see if the node has been visited.

5. Graph::BFS():
	a. I still use the same queue, but I reset the queue after the DFS, so DFSQueue is actually just the same queue. Push on the root. So long as my queue isn’t empty, I wanna grab ALL adjacent vertices and push them on my queue while 1 at a time popping them off and checking all of their adjacent vertices and repeating.

6. Graph::findArticulationPoints():
	a.My solution to findArticulationPoints was drafted from the simple idea of that if a Vertex has a child, and that child has a child, the middle vertex here is a articulation point, because the graph will become disjoint if it is removed. I make a little array of vertices called AP which holds a 1 is that vertex is an articulation point. I then use that 1 to determine whether or not we have an articulation point or not.